<?php

namespace App\Filament\Resources\Jadwals\Pages;

use App\Filament\Resources\Jadwals\JadwalResource;
use App\Models\JadwalPelajaran;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;
use Filament\Schemas\Components\Tabs\Tab;
use Illuminate\Database\Eloquent\Builder;

class ListJadwals extends ListRecords
{
    protected static string $resource = JadwalResource::class;

    public function getTabs(): array
    {
        $hari = [
            'senin'  => 'Senin',
            'selasa' => 'Selasa',
            'rabu'   => 'Rabu',
            'kamis'  => 'Kamis',
            'jumat'  => 'Jumat',
            'sabtu'  => 'Sabtu',
        ];

        $tabs = [
            'semua' => Tab::make('Semua')
                ->modifyQueryUsing(fn(Builder $q) => $q),
        ];

        foreach ($hari as $key => $label) {
            $tabs[$key] = Tab::make($label)
                ->modifyQueryUsing(fn(Builder $q) => $q->where('hari', $key));
        }

        return $tabs;
    }

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make()
                ->label('Tambah Jadwal')
                ->icon('heroicon-o-plus'),
        ];
    }
}